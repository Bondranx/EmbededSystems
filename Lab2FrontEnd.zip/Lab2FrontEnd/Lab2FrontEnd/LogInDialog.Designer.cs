﻿namespace Lab2FrontEnd
{
    partial class LogInDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this._txbEmpID = new System.Windows.Forms.TextBox();
            this._txbEmpPass = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this._btnLogIn = new System.Windows.Forms.Button();
            this._btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee ID:";
            // 
            // _txbEmpID
            // 
            this._txbEmpID.Location = new System.Drawing.Point(103, 10);
            this._txbEmpID.Name = "_txbEmpID";
            this._txbEmpID.Size = new System.Drawing.Size(100, 20);
            this._txbEmpID.TabIndex = 1;
            // 
            // _txbEmpPass
            // 
            this._txbEmpPass.Location = new System.Drawing.Point(103, 47);
            this._txbEmpPass.MaxLength = 30;
            this._txbEmpPass.Name = "_txbEmpPass";
            this._txbEmpPass.Size = new System.Drawing.Size(100, 20);
            this._txbEmpPass.TabIndex = 2;
            this._txbEmpPass.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password:";
            // 
            // _btnLogIn
            // 
            this._btnLogIn.Location = new System.Drawing.Point(16, 86);
            this._btnLogIn.Name = "_btnLogIn";
            this._btnLogIn.Size = new System.Drawing.Size(75, 23);
            this._btnLogIn.TabIndex = 4;
            this._btnLogIn.Text = "Log In";
            this._btnLogIn.UseVisualStyleBackColor = true;
            this._btnLogIn.Click += new System.EventHandler(this._btnLogIn_Click);
            // 
            // _btnCancel
            // 
            this._btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._btnCancel.Location = new System.Drawing.Point(128, 86);
            this._btnCancel.MaximumSize = new System.Drawing.Size(75, 23);
            this._btnCancel.MinimumSize = new System.Drawing.Size(75, 23);
            this._btnCancel.Name = "_btnCancel";
            this._btnCancel.Size = new System.Drawing.Size(75, 23);
            this._btnCancel.TabIndex = 5;
            this._btnCancel.Text = "Cancel";
            this._btnCancel.UseVisualStyleBackColor = true;
            // 
            // LogInDialog
            // 
            this.AcceptButton = this._btnLogIn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._btnCancel;
            this.ClientSize = new System.Drawing.Size(218, 121);
            this.Controls.Add(this._btnCancel);
            this.Controls.Add(this._btnLogIn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this._txbEmpPass);
            this.Controls.Add(this._txbEmpID);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LogInDialog";
            this.ShowInTaskbar = false;
            this.Text = "User Log In";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox _txbEmpID;
        private System.Windows.Forms.TextBox _txbEmpPass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button _btnLogIn;
        private System.Windows.Forms.Button _btnCancel;
    }
}