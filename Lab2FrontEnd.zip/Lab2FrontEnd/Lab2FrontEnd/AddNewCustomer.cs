﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab2FrontEnd
{
    public partial class AddNewCustomer : Form
    {
        private string sConnection = ConnectionString.sConnection;

        public AddNewCustomer()
        {
            InitializeComponent();
        }

        private void _btnAddCustomer_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("AddCustomer", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlParameter param = new SqlParameter("@CustomerID", SqlDbType.NChar, 5);
                    param.Value = _txbCustomerID.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@CompanyName", SqlDbType.NVarChar, 40);
                    param.Value = _txbCompanyName.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@ContactName", SqlDbType.NVarChar, 30);
                    param.Value = _txbContactName.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@ContactTitle", SqlDbType.NVarChar, 30);
                    param.Value = _txbContactTitle.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Address", SqlDbType.NVarChar, 60);
                    param.Value = _txbAddress.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@City", SqlDbType.NVarChar, 15);
                    param.Value = _txbCity.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Region", SqlDbType.NVarChar, 15);
                    param.Value = _txbRegion.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@PostalCode", SqlDbType.NVarChar, 10);
                    param.Value = _txbPostalCode.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Country", SqlDbType.NVarChar, 15);
                    param.Value = _txbCountry.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Phone", SqlDbType.NVarChar, 24);
                    param.Value = _txbPhone.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Fax", SqlDbType.NVarChar, 24);
                    param.Value = _txbFax.Text;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Return", SqlDbType.Int);
                    param.Direction = ParameterDirection.ReturnValue;
                    comm.Parameters.Add(param);

                    comm.ExecuteNonQuery();

                    int iReturn = (int)comm.Parameters["@Return"].Value;
                    _lblStatus.ForeColor = Color.Red;;

                    switch (iReturn)
                    {
                        case 0: 
                            _lblStatus.ForeColor = Color.Green;
                            _lblStatus.Text = "Customer Registration Successful!";
                            break;
                        case 1:
                            _lblStatus.Text = "Customer ID must be supplied!"; break;
                        case 2:
                            _lblStatus.Text = "Company Name must be supplied!"; break;
                        case 3:
                            _lblStatus.Text = "Customer ID must be 5 characters!"; break;
                        case 4:
                            _lblStatus.Text = "Customer ID already exists!"; break;
                        case 5:
                            _lblStatus.Text = "Error occured during insert!"; break;
                    }

                }
                    
                conn.Close();
            }
        }

        private void _btnFinished_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
