﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab2FrontEnd
{
    class ConnectionString
    {
        public const string sConnection = "Data Source=bender.net.nait.ca,24680;Initial Catalog=skelemen1_Northwind;Persist Security Info=true;User Id=skelemen1;Password=New_987";
    }
}
