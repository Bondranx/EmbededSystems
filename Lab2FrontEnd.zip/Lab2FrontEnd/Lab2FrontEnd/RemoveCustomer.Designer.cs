﻿namespace Lab2FrontEnd
{
    partial class RemoveCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._cmbCustomerID = new System.Windows.Forms.ComboBox();
            this._btnRemove = new System.Windows.Forms.Button();
            this._btnFinished = new System.Windows.Forms.Button();
            this._lblRemovalStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // _cmbCustomerID
            // 
            this._cmbCustomerID.FormattingEnabled = true;
            this._cmbCustomerID.Location = new System.Drawing.Point(12, 12);
            this._cmbCustomerID.Name = "_cmbCustomerID";
            this._cmbCustomerID.Size = new System.Drawing.Size(260, 21);
            this._cmbCustomerID.TabIndex = 0;
            // 
            // _btnRemove
            // 
            this._btnRemove.Location = new System.Drawing.Point(77, 47);
            this._btnRemove.Name = "_btnRemove";
            this._btnRemove.Size = new System.Drawing.Size(131, 23);
            this._btnRemove.TabIndex = 1;
            this._btnRemove.Text = "Remove";
            this._btnRemove.UseVisualStyleBackColor = true;
            this._btnRemove.Click += new System.EventHandler(this._btnRemove_Click);
            // 
            // _btnFinished
            // 
            this._btnFinished.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._btnFinished.Location = new System.Drawing.Point(77, 113);
            this._btnFinished.Name = "_btnFinished";
            this._btnFinished.Size = new System.Drawing.Size(131, 23);
            this._btnFinished.TabIndex = 2;
            this._btnFinished.Text = "Finished";
            this._btnFinished.UseVisualStyleBackColor = true;
            // 
            // _lblRemovalStatus
            // 
            this._lblRemovalStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblRemovalStatus.Location = new System.Drawing.Point(12, 79);
            this._lblRemovalStatus.Name = "_lblRemovalStatus";
            this._lblRemovalStatus.Size = new System.Drawing.Size(260, 23);
            this._lblRemovalStatus.TabIndex = 3;
            this._lblRemovalStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RemoveCustomer
            // 
            this.AcceptButton = this._btnFinished;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._btnFinished;
            this.ClientSize = new System.Drawing.Size(284, 148);
            this.Controls.Add(this._lblRemovalStatus);
            this.Controls.Add(this._btnFinished);
            this.Controls.Add(this._btnRemove);
            this.Controls.Add(this._cmbCustomerID);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RemoveCustomer";
            this.ShowInTaskbar = false;
            this.Text = "Remove Customer";
            this.Load += new System.EventHandler(this.RemoveCustomer_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox _cmbCustomerID;
        private System.Windows.Forms.Button _btnRemove;
        private System.Windows.Forms.Button _btnFinished;
        private System.Windows.Forms.Label _lblRemovalStatus;
    }
}