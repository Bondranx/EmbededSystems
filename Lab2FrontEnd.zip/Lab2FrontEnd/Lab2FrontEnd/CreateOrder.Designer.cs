﻿namespace Lab2FrontEnd
{
    partial class CreateOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this._cmbCustomerID = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this._cmbEmployees = new System.Windows.Forms.ComboBox();
            this._btnCreate = new System.Windows.Forms.Button();
            this._btnFinished = new System.Windows.Forms.Button();
            this._lblStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer ID:";
            // 
            // _cmbCustomerID
            // 
            this._cmbCustomerID.FormattingEnabled = true;
            this._cmbCustomerID.Location = new System.Drawing.Point(87, 10);
            this._cmbCustomerID.Name = "_cmbCustomerID";
            this._cmbCustomerID.Size = new System.Drawing.Size(244, 21);
            this._cmbCustomerID.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Employee:";
            // 
            // _cmbEmployees
            // 
            this._cmbEmployees.FormattingEnabled = true;
            this._cmbEmployees.Location = new System.Drawing.Point(87, 38);
            this._cmbEmployees.Name = "_cmbEmployees";
            this._cmbEmployees.Size = new System.Drawing.Size(164, 21);
            this._cmbEmployees.TabIndex = 3;
            // 
            // _btnCreate
            // 
            this._btnCreate.Location = new System.Drawing.Point(66, 103);
            this._btnCreate.Name = "_btnCreate";
            this._btnCreate.Size = new System.Drawing.Size(93, 23);
            this._btnCreate.TabIndex = 4;
            this._btnCreate.Text = "Create Order";
            this._btnCreate.UseVisualStyleBackColor = true;
            this._btnCreate.Click += new System.EventHandler(this._btnCreate_Click);
            // 
            // _btnFinished
            // 
            this._btnFinished.Location = new System.Drawing.Point(202, 103);
            this._btnFinished.Name = "_btnFinished";
            this._btnFinished.Size = new System.Drawing.Size(75, 23);
            this._btnFinished.TabIndex = 5;
            this._btnFinished.Text = "Finished";
            this._btnFinished.UseVisualStyleBackColor = true;
            this._btnFinished.Click += new System.EventHandler(this._btnFinished_Click);
            // 
            // _lblStatus
            // 
            this._lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblStatus.Location = new System.Drawing.Point(16, 70);
            this._lblStatus.Name = "_lblStatus";
            this._lblStatus.Size = new System.Drawing.Size(315, 23);
            this._lblStatus.TabIndex = 6;
            this._lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CreateOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 142);
            this.Controls.Add(this._lblStatus);
            this.Controls.Add(this._btnFinished);
            this.Controls.Add(this._btnCreate);
            this.Controls.Add(this._cmbEmployees);
            this.Controls.Add(this.label2);
            this.Controls.Add(this._cmbCustomerID);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CreateOrder";
            this.ShowInTaskbar = false;
            this.Text = "Create New Customer Order";
            this.Load += new System.EventHandler(this.CreateOrder_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox _cmbCustomerID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox _cmbEmployees;
        private System.Windows.Forms.Button _btnCreate;
        private System.Windows.Forms.Button _btnFinished;
        private System.Windows.Forms.Label _lblStatus;
    }
}