﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab2FrontEnd
{
    public partial class RemoveCustomer : Form
    {
        private string sConnection = ConnectionString.sConnection;

        public RemoveCustomer()
        {
            InitializeComponent();
        }

        private void RemoveCustomer_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("GetCustomers", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlDataReader Reader = comm.ExecuteReader();

                    if (Reader.HasRows)
                        while (Reader.Read())
                        {
                            _cmbCustomerID.Items.Add(Reader.GetValue(0));
                        }

                    Reader.Close();
                }

                conn.Close();
            }
        }

        private void _btnRemove_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("RemoveCustomer", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlParameter param = new SqlParameter("@CustomerID", SqlDbType.NChar, 5);
                    param.Value = _cmbCustomerID.SelectedItem.ToString().Substring(0,5);
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Return", SqlDbType.Int);
                    param.Direction = ParameterDirection.ReturnValue;
                    comm.Parameters.Add(param);

                    comm.ExecuteNonQuery();

                    int iReturn = (int)comm.Parameters["@Return"].Value;
                    _lblRemovalStatus.ForeColor = Color.Red;

                    switch (iReturn)
                    {
                        case 0:
                            _lblRemovalStatus.ForeColor = Color.Green;
                            _lblRemovalStatus.Text = "Customer Backup and Removal Successful!";
                            break;
                        case 1:
                            _lblRemovalStatus.Text = "Error Archiving Customer Order Details!";
                            break;
                        case 2:
                            _lblRemovalStatus.Text = "Error Archiving Customer Orders!";
                            break;
                        case 3:
                            _lblRemovalStatus.Text = "Error Archiving Customer!";
                            break;
                        case 4:
                            _lblRemovalStatus.Text = "Error Removing Customer Order Details!";
                            break;
                        case 5:
                            _lblRemovalStatus.Text = "Error Removing Customer Orders!";
                            break;
                        case 6:
                            _lblRemovalStatus.Text = "Error Removing Customer!";
                            break;
                    }
                }

                conn.Close();
            }
        }
    }
}
