﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab2FrontEnd
{
    public partial class CreateOrder : Form
    {
        private string sConnection = ConnectionString.sConnection;

        public CreateOrder()
        {
            InitializeComponent();
        }

        private void CreateOrder_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("GetCustomers", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlDataReader Reader = comm.ExecuteReader();

                    if (Reader.HasRows)
                        while (Reader.Read())
                        {
                            _cmbCustomerID.Items.Add(Reader.GetValue(0));
                        }

                    Reader.Close();
                }

                conn.Close();
            }


            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("GetEmployees", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlDataReader Reader = comm.ExecuteReader();

                    if (Reader.HasRows)
                        while (Reader.Read())
                        {
                            _cmbEmployees.Items.Add(Reader.GetValue(0));
                        }

                    Reader.Close();
                }

                conn.Close();
            }
        }

        private void _btnFinished_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void _btnCreate_Click(object sender, EventArgs e)
        {
            if (_cmbCustomerID.SelectedIndex == -1 || _cmbEmployees.SelectedIndex == -1) return;


            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("CreateNewOrder", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlParameter param = new SqlParameter("@CustomerID", SqlDbType.NChar, 5);
                    param.Value = _cmbCustomerID.SelectedItem.ToString().Substring(0, 5);
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@EmployeeID", SqlDbType.Int);
                    param.Value = int.Parse(_cmbEmployees.SelectedItem.ToString().Substring(0, 1));
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Return", SqlDbType.Int);
                    param.Direction = ParameterDirection.ReturnValue;
                    comm.Parameters.Add(param);

                    comm.ExecuteNonQuery();

                    int iReturn = (int)comm.Parameters["@Return"].Value;

                    if (iReturn == 1)
                    {
                        _lblStatus.ForeColor = Color.Red;
                        _lblStatus.Text = "Order Creation Failed!";
                    }
                    else
                    {
                        _lblStatus.ForeColor = Color.Green;
                        _lblStatus.Text = "Order Creation Successful!";
                    }
                }

                conn.Close();
            }
        }
    }
}
