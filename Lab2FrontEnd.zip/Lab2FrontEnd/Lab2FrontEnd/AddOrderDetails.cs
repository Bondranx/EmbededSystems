﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab2FrontEnd
{
    public partial class AddOrderDetails : Form
    {
        private string sConnection = ConnectionString.sConnection;

        public AddOrderDetails()
        {
            InitializeComponent();
        }

        private void AddOrderDetails_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("GetCustomers", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlDataReader Reader = comm.ExecuteReader();

                    if (Reader.HasRows)
                        while (Reader.Read())
                        {
                            _cmbCustomers.Items.Add(Reader.GetValue(0));
                        }

                    Reader.Close();
                }

                conn.Close();
            }


            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("GetProducts", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlDataReader Reader = comm.ExecuteReader();

                    if (Reader.HasRows)
                        while (Reader.Read())
                        {
                            _cmbProducts.Items.Add(Reader.GetValue(0));
                        }

                    Reader.Close();
                }

                conn.Close();
            }
        }

        private void _cmbCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            _cmbOrders.Items.Clear();

            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("GetCustomerOrders", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlParameter param = new SqlParameter("@CustomerID", SqlDbType.NChar, 5);
                    param.Value = _cmbCustomers.SelectedItem.ToString().Substring(0, 5);
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    SqlDataReader Reader = comm.ExecuteReader();

                    if (Reader.HasRows)
                        while (Reader.Read())
                        {
                            _cmbOrders.Items.Add(Reader.GetValue(0));
                        }

                    Reader.Close();
                }

                conn.Close();
            }
        }

        private void _btnAddDetail_Click(object sender, EventArgs e)
        {
            if (_cmbCustomers.SelectedIndex == -1 || _cmbProducts.SelectedIndex == -1
                || _cmbOrders.SelectedIndex == -1) return;


            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("AddOrderDetail", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlParameter param = new SqlParameter("@OrderID", SqlDbType.Int);
                    param.Value = int.Parse(_cmbOrders.SelectedItem.ToString());
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@ProductID", SqlDbType.Int);
                    param.Value = int.Parse(_cmbProducts.SelectedItem.ToString().Substring(0, 2).Trim());
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Quantity", SqlDbType.Int);
                    param.Value = (int)_numQuantity.Value;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Return", SqlDbType.Int);
                    param.Direction = ParameterDirection.ReturnValue;
                    comm.Parameters.Add(param);

                    comm.ExecuteNonQuery();

                    int iReturn = (int)comm.Parameters["@Return"].Value;

                    if (iReturn == 1)
                    {
                        _lblStatus.ForeColor = Color.Red;
                        _lblStatus.Text = "Detail Insertion Failed!";
                    }
                    else
                    {
                        _lblStatus.ForeColor = Color.Green;
                        _lblStatus.Text = "Detail Successfully Inserted!";
                    }
                }

                conn.Close();
            }
        }

        private void _btnFinished_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
