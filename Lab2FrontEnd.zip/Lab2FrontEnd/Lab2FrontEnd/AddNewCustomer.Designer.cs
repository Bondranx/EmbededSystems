﻿namespace Lab2FrontEnd
{
    partial class AddNewCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this._txbCustomerID = new System.Windows.Forms.TextBox();
            this._txbCompanyName = new System.Windows.Forms.TextBox();
            this._txbContactName = new System.Windows.Forms.TextBox();
            this._txbContactTitle = new System.Windows.Forms.TextBox();
            this._txbAddress = new System.Windows.Forms.TextBox();
            this._txbCity = new System.Windows.Forms.TextBox();
            this._txbRegion = new System.Windows.Forms.TextBox();
            this._txbPostalCode = new System.Windows.Forms.TextBox();
            this._txbCountry = new System.Windows.Forms.TextBox();
            this._txbFax = new System.Windows.Forms.TextBox();
            this._txbPhone = new System.Windows.Forms.TextBox();
            this._btnAddCustomer = new System.Windows.Forms.Button();
            this._lblStatus = new System.Windows.Forms.Label();
            this._btnFinished = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Company Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Contact Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Contact Title:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(49, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(70, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "City:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(53, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Region:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 163);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Postal Code:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(51, 185);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Country:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(56, 207);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Phone:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(70, 229);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Fax:";
            // 
            // _txbCustomerID
            // 
            this._txbCustomerID.Location = new System.Drawing.Point(105, 6);
            this._txbCustomerID.MaxLength = 5;
            this._txbCustomerID.Name = "_txbCustomerID";
            this._txbCustomerID.Size = new System.Drawing.Size(167, 20);
            this._txbCustomerID.TabIndex = 11;
            // 
            // _txbCompanyName
            // 
            this._txbCompanyName.Location = new System.Drawing.Point(105, 28);
            this._txbCompanyName.MaxLength = 40;
            this._txbCompanyName.Name = "_txbCompanyName";
            this._txbCompanyName.Size = new System.Drawing.Size(167, 20);
            this._txbCompanyName.TabIndex = 12;
            // 
            // _txbContactName
            // 
            this._txbContactName.Location = new System.Drawing.Point(105, 50);
            this._txbContactName.MaxLength = 30;
            this._txbContactName.Name = "_txbContactName";
            this._txbContactName.Size = new System.Drawing.Size(167, 20);
            this._txbContactName.TabIndex = 13;
            // 
            // _txbContactTitle
            // 
            this._txbContactTitle.Location = new System.Drawing.Point(105, 72);
            this._txbContactTitle.MaxLength = 30;
            this._txbContactTitle.Name = "_txbContactTitle";
            this._txbContactTitle.Size = new System.Drawing.Size(167, 20);
            this._txbContactTitle.TabIndex = 14;
            // 
            // _txbAddress
            // 
            this._txbAddress.Location = new System.Drawing.Point(105, 94);
            this._txbAddress.MaxLength = 60;
            this._txbAddress.Name = "_txbAddress";
            this._txbAddress.Size = new System.Drawing.Size(167, 20);
            this._txbAddress.TabIndex = 15;
            // 
            // _txbCity
            // 
            this._txbCity.Location = new System.Drawing.Point(105, 116);
            this._txbCity.MaxLength = 15;
            this._txbCity.Name = "_txbCity";
            this._txbCity.Size = new System.Drawing.Size(167, 20);
            this._txbCity.TabIndex = 16;
            // 
            // _txbRegion
            // 
            this._txbRegion.Location = new System.Drawing.Point(105, 138);
            this._txbRegion.MaxLength = 15;
            this._txbRegion.Name = "_txbRegion";
            this._txbRegion.Size = new System.Drawing.Size(167, 20);
            this._txbRegion.TabIndex = 17;
            // 
            // _txbPostalCode
            // 
            this._txbPostalCode.Location = new System.Drawing.Point(105, 160);
            this._txbPostalCode.MaxLength = 10;
            this._txbPostalCode.Name = "_txbPostalCode";
            this._txbPostalCode.Size = new System.Drawing.Size(167, 20);
            this._txbPostalCode.TabIndex = 18;
            // 
            // _txbCountry
            // 
            this._txbCountry.Location = new System.Drawing.Point(105, 182);
            this._txbCountry.MaxLength = 15;
            this._txbCountry.Name = "_txbCountry";
            this._txbCountry.Size = new System.Drawing.Size(167, 20);
            this._txbCountry.TabIndex = 19;
            // 
            // _txbFax
            // 
            this._txbFax.Location = new System.Drawing.Point(105, 226);
            this._txbFax.MaxLength = 24;
            this._txbFax.Name = "_txbFax";
            this._txbFax.Size = new System.Drawing.Size(167, 20);
            this._txbFax.TabIndex = 21;
            // 
            // _txbPhone
            // 
            this._txbPhone.Location = new System.Drawing.Point(105, 204);
            this._txbPhone.MaxLength = 24;
            this._txbPhone.Name = "_txbPhone";
            this._txbPhone.Size = new System.Drawing.Size(167, 20);
            this._txbPhone.TabIndex = 20;
            // 
            // _btnAddCustomer
            // 
            this._btnAddCustomer.Location = new System.Drawing.Point(15, 259);
            this._btnAddCustomer.Name = "_btnAddCustomer";
            this._btnAddCustomer.Size = new System.Drawing.Size(257, 23);
            this._btnAddCustomer.TabIndex = 22;
            this._btnAddCustomer.Text = "Register New Customer Account";
            this._btnAddCustomer.UseVisualStyleBackColor = true;
            this._btnAddCustomer.Click += new System.EventHandler(this._btnAddCustomer_Click);
            // 
            // _lblStatus
            // 
            this._lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblStatus.Location = new System.Drawing.Point(15, 286);
            this._lblStatus.Name = "_lblStatus";
            this._lblStatus.Size = new System.Drawing.Size(257, 24);
            this._lblStatus.TabIndex = 24;
            this._lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _btnFinished
            // 
            this._btnFinished.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._btnFinished.Location = new System.Drawing.Point(84, 314);
            this._btnFinished.Name = "_btnFinished";
            this._btnFinished.Size = new System.Drawing.Size(117, 23);
            this._btnFinished.TabIndex = 25;
            this._btnFinished.Text = "Finished";
            this._btnFinished.UseVisualStyleBackColor = true;
            this._btnFinished.Click += new System.EventHandler(this._btnFinished_Click);
            // 
            // AddNewCustomer
            // 
            this.AcceptButton = this._btnFinished;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._btnFinished;
            this.ClientSize = new System.Drawing.Size(284, 350);
            this.Controls.Add(this._btnFinished);
            this.Controls.Add(this._lblStatus);
            this.Controls.Add(this._btnAddCustomer);
            this.Controls.Add(this._txbPhone);
            this.Controls.Add(this._txbFax);
            this.Controls.Add(this._txbCountry);
            this.Controls.Add(this._txbPostalCode);
            this.Controls.Add(this._txbRegion);
            this.Controls.Add(this._txbCity);
            this.Controls.Add(this._txbAddress);
            this.Controls.Add(this._txbContactTitle);
            this.Controls.Add(this._txbContactName);
            this.Controls.Add(this._txbCompanyName);
            this.Controls.Add(this._txbCustomerID);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddNewCustomer";
            this.ShowInTaskbar = false;
            this.Text = "AddNewCustomer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox _txbCustomerID;
        private System.Windows.Forms.TextBox _txbCompanyName;
        private System.Windows.Forms.TextBox _txbContactName;
        private System.Windows.Forms.TextBox _txbContactTitle;
        private System.Windows.Forms.TextBox _txbAddress;
        private System.Windows.Forms.TextBox _txbCity;
        private System.Windows.Forms.TextBox _txbRegion;
        private System.Windows.Forms.TextBox _txbPostalCode;
        private System.Windows.Forms.TextBox _txbCountry;
        private System.Windows.Forms.TextBox _txbFax;
        private System.Windows.Forms.TextBox _txbPhone;
        private System.Windows.Forms.Button _btnAddCustomer;
        private System.Windows.Forms.Label _lblStatus;
        private System.Windows.Forms.Button _btnFinished;
    }
}