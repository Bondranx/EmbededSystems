﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab2FrontEnd
{
    public partial class LogInDialog : Form
    {
        private bool bIsEmployee = false;
        private bool bIsManager = false;
        private string sEmployeeName = "";
        private DialogResult drOnClose = DialogResult.Cancel;
        private string sConnection = ConnectionString.sConnection;

        public LogInDialog()
        {
            InitializeComponent();
        }

        private void _btnLogIn_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                try
                {
                    using (SqlCommand comm = new SqlCommand("ValidateEmployee", conn))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        SqlParameter param = new SqlParameter("@EmployeeID", SqlDbType.Int);
                        param.Value = int.Parse(_txbEmpID.Text);
                        param.Direction = ParameterDirection.Input;
                        comm.Parameters.Add(param);

                        param = new SqlParameter("@Password", SqlDbType.NVarChar, 30);
                        param.Value = _txbEmpPass.Text;
                        param.Direction = ParameterDirection.Input;
                        comm.Parameters.Add(param);

                        param = new SqlParameter("@IsEmployee", SqlDbType.Bit);
                        param.Direction = ParameterDirection.Output;
                        comm.Parameters.Add(param);

                        param = new SqlParameter("@IsManager", SqlDbType.Bit);
                        param.Direction = ParameterDirection.Output;
                        comm.Parameters.Add(param);

                        param = new SqlParameter("@Name", SqlDbType.NVarChar, 31);
                        param.Direction = ParameterDirection.Output;
                        comm.Parameters.Add(param);

                        comm.ExecuteNonQuery();

                        try
                        {
                            bIsEmployee = (bool)comm.Parameters["@IsEmployee"].Value;
                            sEmployeeName = comm.Parameters["@Name"].Value.ToString();
                            try
                            {
                                bIsManager = (bool)comm.Parameters["@IsManager"].Value;
                            }
                            catch
                            {
                                bIsManager = false;
                            }
                        }
                        catch
                        {
                            bIsEmployee = false;
                        }

                        conn.Close();
                    }
                }
                catch
                {

                }
                finally
                {
                    conn.Close();
                }
            }      
            
            drOnClose = System.Windows.Forms.DialogResult.OK;
            Close();
        }

        public bool IsEmployee
        {
            get { return bIsEmployee; }
        }

        public bool IsManger
        {
            get { return bIsManager; }
        }

        public string EmployeeName
        {
            get { return sEmployeeName; }
        }

        public DialogResult OnClose
        {
            get { return drOnClose; }
        }
   }
}
