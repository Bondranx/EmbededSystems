﻿namespace Lab2FrontEnd
{
    partial class AddOrderDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this._cmbCustomers = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this._cmbOrders = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this._cmbProducts = new System.Windows.Forms.ComboBox();
            this._numQuantity = new System.Windows.Forms.NumericUpDown();
            this._btnAddDetail = new System.Windows.Forms.Button();
            this._btnFinished = new System.Windows.Forms.Button();
            this._lblStatus = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._numQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer:";
            // 
            // _cmbCustomers
            // 
            this._cmbCustomers.FormattingEnabled = true;
            this._cmbCustomers.Location = new System.Drawing.Point(85, 10);
            this._cmbCustomers.Name = "_cmbCustomers";
            this._cmbCustomers.Size = new System.Drawing.Size(187, 21);
            this._cmbCustomers.TabIndex = 1;
            this._cmbCustomers.SelectedIndexChanged += new System.EventHandler(this._cmbCustomers_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Order:";
            // 
            // _cmbOrders
            // 
            this._cmbOrders.FormattingEnabled = true;
            this._cmbOrders.Location = new System.Drawing.Point(85, 42);
            this._cmbOrders.Name = "_cmbOrders";
            this._cmbOrders.Size = new System.Drawing.Size(121, 21);
            this._cmbOrders.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Product:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Quantity:";
            // 
            // _cmbProducts
            // 
            this._cmbProducts.FormattingEnabled = true;
            this._cmbProducts.Location = new System.Drawing.Point(85, 76);
            this._cmbProducts.Name = "_cmbProducts";
            this._cmbProducts.Size = new System.Drawing.Size(187, 21);
            this._cmbProducts.TabIndex = 6;
            // 
            // _numQuantity
            // 
            this._numQuantity.Location = new System.Drawing.Point(85, 107);
            this._numQuantity.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this._numQuantity.Name = "_numQuantity";
            this._numQuantity.Size = new System.Drawing.Size(120, 20);
            this._numQuantity.TabIndex = 7;
            // 
            // _btnAddDetail
            // 
            this._btnAddDetail.Location = new System.Drawing.Point(47, 175);
            this._btnAddDetail.Name = "_btnAddDetail";
            this._btnAddDetail.Size = new System.Drawing.Size(75, 23);
            this._btnAddDetail.TabIndex = 8;
            this._btnAddDetail.Text = "Add Detail";
            this._btnAddDetail.UseVisualStyleBackColor = true;
            this._btnAddDetail.Click += new System.EventHandler(this._btnAddDetail_Click);
            // 
            // _btnFinished
            // 
            this._btnFinished.Location = new System.Drawing.Point(160, 175);
            this._btnFinished.Name = "_btnFinished";
            this._btnFinished.Size = new System.Drawing.Size(75, 23);
            this._btnFinished.TabIndex = 9;
            this._btnFinished.Text = "Finished";
            this._btnFinished.UseVisualStyleBackColor = true;
            this._btnFinished.Click += new System.EventHandler(this._btnFinished_Click);
            // 
            // _lblStatus
            // 
            this._lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblStatus.Location = new System.Drawing.Point(15, 142);
            this._lblStatus.Name = "_lblStatus";
            this._lblStatus.Size = new System.Drawing.Size(257, 23);
            this._lblStatus.TabIndex = 10;
            this._lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AddOrderDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 213);
            this.Controls.Add(this._lblStatus);
            this.Controls.Add(this._btnFinished);
            this.Controls.Add(this._btnAddDetail);
            this.Controls.Add(this._numQuantity);
            this.Controls.Add(this._cmbProducts);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this._cmbOrders);
            this.Controls.Add(this.label2);
            this.Controls.Add(this._cmbCustomers);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddOrderDetails";
            this.ShowInTaskbar = false;
            this.Text = "Add Order Details";
            this.Load += new System.EventHandler(this.AddOrderDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this._numQuantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox _cmbCustomers;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox _cmbOrders;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox _cmbProducts;
        private System.Windows.Forms.NumericUpDown _numQuantity;
        private System.Windows.Forms.Button _btnAddDetail;
        private System.Windows.Forms.Button _btnFinished;
        private System.Windows.Forms.Label _lblStatus;
    }
}