﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab2FrontEnd
{
    public partial class GrantDiscount : Form
    {
        private string sConnection = ConnectionString.sConnection;

        public GrantDiscount()
        {
            InitializeComponent();
        }

        private void GrantDiscount_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("GetCustomers", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlDataReader Reader = comm.ExecuteReader();

                    if (Reader.HasRows)
                        while (Reader.Read())
                        {
                            _cmbCustomerID.Items.Add(Reader.GetValue(0));
                        }

                    Reader.Close();
                }

                conn.Close();
            }

            
        }

        private void _cmbCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {
            _cmbOrderNumbers.Items.Clear();

            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("GetCustomerOrders", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlParameter param = new SqlParameter("@CustomerID", SqlDbType.NChar, 5);
                    param.Value = _cmbCustomerID.SelectedItem.ToString().Substring(0, 5);
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);
                    
                    SqlDataReader Reader = comm.ExecuteReader();

                    if (Reader.HasRows)
                        while (Reader.Read())
                        {
                            _cmbOrderNumbers.Items.Add(Reader.GetValue(0));
                        }

                    Reader.Close();
                }

                conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (_cmbOrderNumbers.SelectedIndex == -1) return;

            using (SqlConnection conn = new SqlConnection(sConnection))
            {
                conn.Open();

                using (SqlCommand comm = new SqlCommand("GrantDiscount", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;

                    SqlParameter param = new SqlParameter("@OrderID", SqlDbType.Int);
                    param.Value = int.Parse(_cmbOrderNumbers.SelectedItem.ToString());
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@DiscountPer", SqlDbType.Int);
                    param.Value = (int)_numDiscountPer.Value;
                    param.Direction = ParameterDirection.Input;
                    comm.Parameters.Add(param);

                    param = new SqlParameter("@Return", SqlDbType.Int);
                    param.Direction = ParameterDirection.ReturnValue;
                    comm.Parameters.Add(param);

                    comm.ExecuteNonQuery();

                    int iReturn = (int)comm.Parameters["@Return"].Value;

                    if (iReturn == 1)
                    {
                        _lblStatus.ForeColor = Color.Red;
                        _lblStatus.Text = "Application of Discount Failed!";
                    }
                    else
                    {
                        _lblStatus.ForeColor = Color.Green;
                        _lblStatus.Text = "Application of Discount Successful!";
                    }
                }

                conn.Close();
            }
        }

        private void _btnFinished_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
