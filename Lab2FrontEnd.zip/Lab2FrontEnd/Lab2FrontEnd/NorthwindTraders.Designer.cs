﻿namespace Lab2FrontEnd
{
    partial class NorthwindTraders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this._lblUserName = new System.Windows.Forms.Label();
            this._btnLogInOut = new System.Windows.Forms.Button();
            this._lblLoginError = new System.Windows.Forms.Label();
            this._btnAddNewCustomer = new System.Windows.Forms.Button();
            this._btnCreateNewOrder = new System.Windows.Forms.Button();
            this._btnEditExistingOrder = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this._btnRemoveCustomer = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "User Name:";
            // 
            // _lblUserName
            // 
            this._lblUserName.AutoSize = true;
            this._lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblUserName.Location = new System.Drawing.Point(81, 9);
            this._lblUserName.Name = "_lblUserName";
            this._lblUserName.Size = new System.Drawing.Size(148, 20);
            this._lblUserName.TabIndex = 2;
            this._lblUserName.Text = "User Not Logged In";
            // 
            // _btnLogInOut
            // 
            this._btnLogInOut.Location = new System.Drawing.Point(15, 39);
            this._btnLogInOut.Name = "_btnLogInOut";
            this._btnLogInOut.Size = new System.Drawing.Size(75, 23);
            this._btnLogInOut.TabIndex = 3;
            this._btnLogInOut.Text = "Log In";
            this._btnLogInOut.UseVisualStyleBackColor = true;
            this._btnLogInOut.Click += new System.EventHandler(this._btnLogInOut_Click);
            // 
            // _lblLoginError
            // 
            this._lblLoginError.AutoSize = true;
            this._lblLoginError.ForeColor = System.Drawing.Color.Red;
            this._lblLoginError.Location = new System.Drawing.Point(109, 44);
            this._lblLoginError.Name = "_lblLoginError";
            this._lblLoginError.Size = new System.Drawing.Size(0, 13);
            this._lblLoginError.TabIndex = 4;
            // 
            // _btnAddNewCustomer
            // 
            this._btnAddNewCustomer.Location = new System.Drawing.Point(35, 19);
            this._btnAddNewCustomer.Name = "_btnAddNewCustomer";
            this._btnAddNewCustomer.Size = new System.Drawing.Size(133, 23);
            this._btnAddNewCustomer.TabIndex = 8;
            this._btnAddNewCustomer.Text = "Add New Customer";
            this._btnAddNewCustomer.UseVisualStyleBackColor = true;
            this._btnAddNewCustomer.Click += new System.EventHandler(this._btnAddNewCustomer_Click);
            // 
            // _btnCreateNewOrder
            // 
            this._btnCreateNewOrder.Location = new System.Drawing.Point(35, 48);
            this._btnCreateNewOrder.Name = "_btnCreateNewOrder";
            this._btnCreateNewOrder.Size = new System.Drawing.Size(133, 23);
            this._btnCreateNewOrder.TabIndex = 9;
            this._btnCreateNewOrder.Text = "Create New Order";
            this._btnCreateNewOrder.UseVisualStyleBackColor = true;
            this._btnCreateNewOrder.Click += new System.EventHandler(this._btnCreateNewOrder_Click);
            // 
            // _btnEditExistingOrder
            // 
            this._btnEditExistingOrder.Location = new System.Drawing.Point(35, 77);
            this._btnEditExistingOrder.Name = "_btnEditExistingOrder";
            this._btnEditExistingOrder.Size = new System.Drawing.Size(133, 23);
            this._btnEditExistingOrder.TabIndex = 10;
            this._btnEditExistingOrder.Text = "Add Order Details";
            this._btnEditExistingOrder.UseVisualStyleBackColor = true;
            this._btnEditExistingOrder.Click += new System.EventHandler(this._btnEditExistingOrder_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this._btnAddNewCustomer);
            this.groupBox1.Controls.Add(this._btnEditExistingOrder);
            this.groupBox1.Controls.Add(this._btnCreateNewOrder);
            this.groupBox1.Location = new System.Drawing.Point(15, 81);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 112);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sales Representative Actions";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this._btnRemoveCustomer);
            this.groupBox2.Location = new System.Drawing.Point(15, 218);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 84);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Manager Only Actions";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(35, 50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Grant Customer Discount";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // _btnRemoveCustomer
            // 
            this._btnRemoveCustomer.Location = new System.Drawing.Point(35, 20);
            this._btnRemoveCustomer.Name = "_btnRemoveCustomer";
            this._btnRemoveCustomer.Size = new System.Drawing.Size(133, 23);
            this._btnRemoveCustomer.TabIndex = 0;
            this._btnRemoveCustomer.Text = "Remove Customer";
            this._btnRemoveCustomer.UseVisualStyleBackColor = true;
            this._btnRemoveCustomer.Click += new System.EventHandler(this._btnRemoveCustomer_Click);
            // 
            // NorthwindTraders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(234, 313);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this._lblLoginError);
            this.Controls.Add(this._btnLogInOut);
            this.Controls.Add(this._lblUserName);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(250, 351);
            this.MinimumSize = new System.Drawing.Size(250, 351);
            this.Name = "NorthwindTraders";
            this.Text = "Northwind Traders";
            this.Load += new System.EventHandler(this.NorthwindTraders_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label _lblUserName;
        private System.Windows.Forms.Button _btnLogInOut;
        private System.Windows.Forms.Label _lblLoginError;
        private System.Windows.Forms.Button _btnAddNewCustomer;
        private System.Windows.Forms.Button _btnCreateNewOrder;
        private System.Windows.Forms.Button _btnEditExistingOrder;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button _btnRemoveCustomer;
    }
}

