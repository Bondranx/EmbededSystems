﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab2FrontEnd
{
    public partial class NorthwindTraders : Form
    {
        public NorthwindTraders()
        {
            InitializeComponent();
        }

        private void NorthwindTraders_Load(object sender, EventArgs e)
        {

            _btnAddNewCustomer.Enabled = false;
            _btnCreateNewOrder.Enabled = false;
            _btnEditExistingOrder.Enabled = false;

            _btnRemoveCustomer.Enabled = false;
            button1.Enabled = false;
        }

        private void _btnLogInOut_Click(object sender, EventArgs e)
        {
            LogInDialog _dlgLogIn = new LogInDialog();

            _dlgLogIn.ShowDialog();
            
            if (_dlgLogIn.OnClose == System.Windows.Forms.DialogResult.OK)
            {
                if (_dlgLogIn.IsEmployee)
                {
                    _lblLoginError.Text = "";
                    _lblUserName.Text = _dlgLogIn.EmployeeName;

                    _btnAddNewCustomer.Enabled = true;
                    _btnCreateNewOrder.Enabled = true;
                    _btnEditExistingOrder.Enabled = true;

                    if (_dlgLogIn.IsManger)
                    {
                        _btnRemoveCustomer.Enabled = true;
                        button1.Enabled = true;
                    }
                    else
                    {
                        _btnRemoveCustomer.Enabled = false;
                        button1.Enabled = false;
                    }
                }
                else
                {
                    _lblUserName.Text = "User Not Logged In";
                    _lblLoginError.Text = "User Does Not Exist!";
                    _btnAddNewCustomer.Enabled = false;
                    _btnCreateNewOrder.Enabled = false;
                    _btnEditExistingOrder.Enabled = false;
                    _btnRemoveCustomer.Enabled = false;
                    button1.Enabled = false;
                }
            }
        }

        private void _btnAddNewCustomer_Click(object sender, EventArgs e)
        {
            AddNewCustomer _dlgAddCustomer = new AddNewCustomer();

            _dlgAddCustomer.ShowDialog();


        }

        private void _btnRemoveCustomer_Click(object sender, EventArgs e)
        {
            RemoveCustomer _dlgRemoveCustomer = new RemoveCustomer();

            _dlgRemoveCustomer.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GrantDiscount _dlgGrantDiscount = new GrantDiscount();

            _dlgGrantDiscount.ShowDialog();
        }

        private void _btnCreateNewOrder_Click(object sender, EventArgs e)
        {
            CreateOrder _dlgCreateOrder = new CreateOrder();

            _dlgCreateOrder.ShowDialog();
        }

        private void _btnEditExistingOrder_Click(object sender, EventArgs e)
        {
            AddOrderDetails _dlgAddDetail = new AddOrderDetails();

            _dlgAddDetail.ShowDialog();
        }


    }
}
