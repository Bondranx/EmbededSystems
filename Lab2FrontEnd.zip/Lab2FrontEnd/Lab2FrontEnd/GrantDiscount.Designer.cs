﻿namespace Lab2FrontEnd
{
    partial class GrantDiscount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this._numDiscountPer = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this._cmbCustomerID = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this._cmbOrderNumbers = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this._lblStatus = new System.Windows.Forms.Label();
            this._btnFinished = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this._numDiscountPer)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Discount Percentage:";
            // 
            // _numDiscountPer
            // 
            this._numDiscountPer.Location = new System.Drawing.Point(129, 11);
            this._numDiscountPer.Name = "_numDiscountPer";
            this._numDiscountPer.Size = new System.Drawing.Size(68, 20);
            this._numDiscountPer.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Customer ID:";
            // 
            // _cmbCustomerID
            // 
            this._cmbCustomerID.FormattingEnabled = true;
            this._cmbCustomerID.Location = new System.Drawing.Point(129, 41);
            this._cmbCustomerID.Name = "_cmbCustomerID";
            this._cmbCustomerID.Size = new System.Drawing.Size(234, 21);
            this._cmbCustomerID.TabIndex = 3;
            this._cmbCustomerID.SelectedIndexChanged += new System.EventHandler(this._cmbCustomerID_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Order Number:";
            // 
            // _cmbOrderNumbers
            // 
            this._cmbOrderNumbers.FormattingEnabled = true;
            this._cmbOrderNumbers.Location = new System.Drawing.Point(129, 73);
            this._cmbOrderNumbers.Name = "_cmbOrderNumbers";
            this._cmbOrderNumbers.Size = new System.Drawing.Size(121, 21);
            this._cmbOrderNumbers.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(128, 112);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Apply Discount";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // _lblStatus
            // 
            this._lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblStatus.Location = new System.Drawing.Point(22, 152);
            this._lblStatus.Name = "_lblStatus";
            this._lblStatus.Size = new System.Drawing.Size(341, 23);
            this._lblStatus.TabIndex = 7;
            this._lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _btnFinished
            // 
            this._btnFinished.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._btnFinished.Location = new System.Drawing.Point(129, 189);
            this._btnFinished.Name = "_btnFinished";
            this._btnFinished.Size = new System.Drawing.Size(121, 23);
            this._btnFinished.TabIndex = 8;
            this._btnFinished.Text = "Finished";
            this._btnFinished.UseVisualStyleBackColor = true;
            this._btnFinished.Click += new System.EventHandler(this._btnFinished_Click);
            // 
            // GrantDiscount
            // 
            this.AcceptButton = this._btnFinished;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._btnFinished;
            this.ClientSize = new System.Drawing.Size(379, 223);
            this.Controls.Add(this._btnFinished);
            this.Controls.Add(this._lblStatus);
            this.Controls.Add(this.button1);
            this.Controls.Add(this._cmbOrderNumbers);
            this.Controls.Add(this.label3);
            this.Controls.Add(this._cmbCustomerID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this._numDiscountPer);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GrantDiscount";
            this.ShowInTaskbar = false;
            this.Text = "Grant Customer Discount";
            this.Load += new System.EventHandler(this.GrantDiscount_Load);
            ((System.ComponentModel.ISupportInitialize)(this._numDiscountPer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown _numDiscountPer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox _cmbCustomerID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox _cmbOrderNumbers;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label _lblStatus;
        private System.Windows.Forms.Button _btnFinished;
    }
}